import { loadDoorLootTables } from "./loaders";

export const fetchLootTables = loadDoorLootTables;
