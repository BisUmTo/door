/// <reference types="vite/client" />

declare const __ENABLE_CACHE__: boolean;
